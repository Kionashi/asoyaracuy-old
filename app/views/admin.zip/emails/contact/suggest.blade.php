<h2>{{$title}}</h2>
{{$body}}
