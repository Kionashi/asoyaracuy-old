@extends('layouts.main')
@section('content')
	
<a href="http://asoyaracuy.tepuchamoy.com.ve/documents/meetings"><div class= col-md-3><h3>Actas de Asamblea</h3>{{ HTML::image('images/folder.png', 'a picture', array('class' => 'img-responsive')) }}</div></a>
	   
<a href="http://asoyaracuy.tepuchamoy.com.ve/documents/organization"><div class= col-md-3><h3>Organizacion de la asociacion</h3>{{ HTML::image('images/folder.png', 'a picture', array('class' => 'img-responsive')) }}</div></a>
	   
<a href="http://asoyaracuy.tepuchamoy.com.ve/documents/intercom"><div class= col-md-3><h3>Intercomunicador</h3>{{ HTML::image('images/folder.png', 'a picture', array('class' => 'img-responsive')) }}</div></a>
	   
<a href="http://asoyaracuy.tepuchamoy.com.ve/documents/documents"><div class= col-md-3><h3>Documentos de la asociación</h3>{{ HTML::image('images/folder.png', 'a picture', array('class' => 'img-responsive')) }}</div></a>

	   
<a href="http://asoyaracuy.tepuchamoy.com.ve/documents/members"><div class= col-md-3><h3>Asociados</h3>{{ HTML::image('images/folder.png', 'a picture', array('class' => 'img-responsive')) }}</div></a>
	   
<a href="http://asoyaracuy.tepuchamoy.com.ve/documents/contracts"><div class= col-md-3><h3>Contratos de Servicios</h3>{{ HTML::image('images/folder.png', 'a picture', array('class' => 'img-responsive')) }}</div></a>
	   
<a href="http://asoyaracuy.tepuchamoy.com.ve/documents/info"><div class= col-md-3><h3>Boletin Informativo NotiYaracuy</h3>{{ HTML::image('images/folder.png', 'a picture', array('class' => 'img-responsive')) }}</div></a>
	   
<a href="http://asoyaracuy.tepuchamoy.com.ve/documents/gallery"><div class= col-md-3><h3>Galeria de fotos</h3>{{ HTML::image('images/folder.png', 'a picture', array('class' => 'img-responsive')) }}</div></a>


@stop